<?php
class DbConf{
    public static $host='127.0.0.1';
    public static $database='concerti';

    public static $username='concerti_user';
    public static $password='c6f45dd885f7c762b54416466dca4272fdca012cec87206884ec0da25c6f8c1de74ed8670c9af01f4d29f3d4affc879e42143e0659723cd78038867a61fc6225';
}
